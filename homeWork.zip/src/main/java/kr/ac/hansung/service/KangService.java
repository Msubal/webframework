package kr.ac.hansung.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import kr.ac.hansung.dao.KangDao;
import kr.ac.hansung.model.Kang;


public class KangService {
	private KangDao kangDao;

	public List<Kang> getCredits() {
		return kangDao.getCredits();
	}
	
	public List<Kang> getTranscriptsYearSemester(){
		return kangDao.getTranscriptsYearSemester();
	}
	
}
