package kr.ac.hansung.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
public class Kang {
	private int year;
	private int semester;
	private String classcode;
	private String classname;
	private String classtype;
	private int grades;
	private int gradesSum;
	
	public Kang() {

	}
	

}
