package kr.ac.hansung.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.ac.hansung.model.Kang;
import kr.ac.hansung.model.Offer;
import kr.ac.hansung.service.KangService;

@Controller
public class OffersController {
	
	@Autowired
	private KangService offersService;

	@RequestMapping("/offers")
	public String showOffers(Model model) {
		List<Kang> offers = offersService.getTranscriptsYearSemester();
		model.addAttribute("offers", offers);
		return "offers";
	}
	
	@RequestMapping("/createoffer")
	public String createOffer(Model model) {
		
		model.addAttribute("offer", new Offer());
		return "createoffer";
	}
}
