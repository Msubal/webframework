package kr.ac.hansung.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import kr.ac.hansung.model.Kang;

public class KangDao {

	private JdbcTemplate jdbcTemplateObject;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	}
	
	// kang talbe의 총 인자 갯수
	public int getRowCount() { 
		String sqlStatement = "select count(*) from Kang";
		return jdbcTemplateObject.queryForObject(sqlStatement, Integer.class);
	}

	public Kang getCredit(String classcode) {
		String sqlStatement = "select * from Kang where classcode=?;";
		return jdbcTemplateObject.queryForObject(sqlStatement, new Object[] { classcode }, new Mapper());
	}


	public List<Kang> getCredits() {

		String sqlStatement = "select * from Kang;";
		return jdbcTemplateObject.query(sqlStatement, new Mapper());
	}

	// 1학기 수강list구하기 
	public List<Kang> getCreditsListFromSemester(int year, int semester) {
		String sqlStatement = "select * from Kang where year=? and semester=?";
		return jdbcTemplateObject.query(sqlStatement, new Object[] { year, semester }, new Mapper());
	}

	// 학기별 수강list구하기
	public List<Kang> getTranscriptsYearSemester() {
		String sqlStatement = "select year,semester,sum(grades) from kang group by year,semester";
		return jdbcTemplateObject.query(sqlStatement, new RowMapper<Kang>() {

			@Override
			public Kang mapRow(ResultSet rs, int rowNum) throws SQLException {
				Kang kang = new Kang();
				kang.setYear(rs.getInt("year"));
				kang.setSemester(rs.getInt("semester"));
				kang.setGradesSum(rs.getInt("sum(grades)"));
				return kang;
			}

		});
	}
	

	public boolean insert(Kang kang) {
		int year = kang.getYear();
		int semester = kang.getSemester();
		String classcode = kang.getClasscode();
		String classname = kang.getClassname();
		String classtype = kang.getClasstype();
		int credits = kang.getGrades();
		String sqlStatement = "insert into Kang (year, semester, classcode, classname, classtype, credits) values (?,?,?,?,?,?)";
		return (jdbcTemplateObject.update(sqlStatement,
				new Object[] { year, semester, classcode, classname, classtype, credits }) == 1);
	}

	public boolean update(Kang kang) {
		String classcode = kang.getClasscode();
		int year = kang.getYear();
		int semester = kang.getSemester();
		String classname = kang.getClassname();
		String classtype = kang.getClasstype();
		int credits = kang.getGrades();
		String sqlStatement = "update Kang set year=?,semester=?, classname=?, classtype=?,credits=? where classcode=?";
		return (jdbcTemplateObject.update(sqlStatement,
				new Object[] { year, semester, classcode, classname, classtype, credits }) == 1);
	}

	public boolean delete(String classcode) {
		String sqlStatement = "delete from Kang where classcode=?";
		return (jdbcTemplateObject.update(sqlStatement, new Object[] { classcode }) == 1);
	}

}
