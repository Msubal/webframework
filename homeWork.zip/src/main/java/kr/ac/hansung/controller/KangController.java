package kr.ac.hansung.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.ac.hansung.model.Kang;
import kr.ac.hansung.service.KangService;

public class KangController {

	private KangService kangService;

	@Autowired
	public void setCreditsService(KangService kangService) {
		this.kangService = kangService;
	}

	@RequestMapping("/semesterGrades")
	public String showCredits_S(Model model) {
		List<Kang> creditslist = kangService.getTranscriptsYearSemester();
		model.addAttribute("credits", creditslist);
		return "semesterGrades";
	}
}
