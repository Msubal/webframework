package kr.ac.hansung.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.hansung.dao.KangDao;
import kr.ac.hansung.model.Kang;

@Service
public class KangService {
	@Autowired
	private KangDao kangDao;

	public List<Kang> getCredits() {
		return kangDao.getCredits();
	}
	
	public List<Kang> getSemester(){
		return kangDao.getSemester();
	}
	
	public List<Kang> getListSemester(int year,int semester){
		return kangDao.getListSemester(year, semester);
	}
	
}
