package kr.ac.hansung.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import kr.ac.hansung.model.Kang;
import kr.ac.hansung.service.KangService;

@Controller
public class KangController {

	@Autowired
	private KangService kangService;

	@RequestMapping("/semester")
	public String showCredits_S(Model model) {
		List<Kang> creditslist = kangService.getSemester();
		model.addAttribute("credits", creditslist);
		return "semester";
	}
	
	@RequestMapping(value = "/creditsdetails")
	public String showCreditsDetails(@RequestParam int year,@RequestParam int semester,  Model model) {
		List<Kang> credits = kangService.getListSemester(year,semester);
		model.addAttribute("credits", credits);
		return "semesterDetails";
	}
	
}
